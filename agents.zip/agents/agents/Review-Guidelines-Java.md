# Review Guidelines Agent for Java Applications

Version: 2.0.0  
Created: November 25, 2025  
Last Updated: November 25, 2025  
Author: Java Code Review Team

/*
 * AI AGENT INSTRUCTIONS - CRITICAL RULES
 * 
 * VERSION RESOLUTION: Read ALL versions from technology-stack.md. Never hardcode.
 *   {{PLACEHOLDER}} = read from technology-stack.md (e.g., {{JAVA_VERSION}} → read Java version)
 * 
 * VALIDATION: Read actual project files (pom.xml, source code). Base findings on evidence only.
 *   Format: "In [file]:[line], found: [actual code]"
 * 
 * THRESHOLDS: Read coverage %, complexity limits from technology-stack.md
 * 
 * FRAMEWORKS: Verify frameworks exist in dependencies before assuming usage
 * 
 * ERROR CODES: Use exact codes from this doc (CUS-001, ORD-002). Don't invent new patterns.
 * 
 * CODE EXAMPLES: Templates only - not actual project code. Don't cite as findings.
 * 
 * WORKFLOW: (1) Read technology-stack.md (2) Read project build file (3) Compare versions
 *           (4) Report mismatches with evidence
 *
 * PURPOSE: Production-ready Java review incorporating exception handling, security (OWASP Top 10),
 *          coding standards, and technology stack validation.
 * 
 * TARGET: Developers, Architects, Security Teams, AI Agents, Code Reviewers
 * 
 * ALIGNMENT: OWASP Top 10 (2025), SANS Top 25, CWE, NIST, ISO 27001
 */

## Table of Contents
1. [Core Features & Objectives](#core-features--objectives)
2. [Review Framework](#review-framework)
3. [Code Organization & Naming](#code-organization--naming)
4. [Exception Handling](#exception-handling)
5. [Security Guidelines](#security-guidelines)
6. [Architecture & Design Patterns](#architecture--design-patterns)
7. [Performance & Optimization](#performance--optimization)
8. [Testing Standards](#testing-standards)
9. [Configuration Management](#configuration-management)
10. [Logging & Monitoring](#logging--monitoring)
11. [API Design](#api-design)
12. [Technology Stack](#technology-stack)
13. [Quality Metrics & Tools](#quality-metrics--tools)
14. [CI/CD Integration](#cicd-integration)
15. [Implementation Checklist](#implementation-checklist)

---

## Core Features & Objectives

### 🎯 Universal Java Standards
- **Java Version**: {{JAVA_VERSION}} - See technology-stack.md for current LTS version
- **Spring Boot**: {{SPRING_BOOT_VERSION}} - See technology-stack.md for current version
- **Build Tools**: {{MAVEN_VERSION}} or {{GRADLE_VERSION}} - See technology-stack.md
- **Enterprise-grade**: Quality benchmarks and best practices
- **Production-ready**: Deployment and operational readiness

**Note**: All version numbers are dynamic placeholders. Refer to technology-stack.md for actual versions.

### 🔍 Comprehensive Review Areas
1. **Architecture & Design**: Clean Architecture, DDD, SOLID principles
2. **Security**: OWASP Top 10, authentication, authorization, encryption
3. **Performance**: Async patterns, database optimization, caching
4. **Code Quality**: Clean code, maintainability, documentation
5. **Exception Handling**: Hierarchical structure, error codes, global handlers
6. **Testing**: Unit, integration, and end-to-end test coverage
7. **Configuration**: Externalized settings, environment management
8. **Logging**: Structured logging, correlation IDs, security

### Primary Review Objectives
1. **Identify Architectural Flaws**: Layer violations, tight coupling, anti-patterns
2. **Ensure Security Compliance**: OWASP Top 10, input validation, secrets management
3. **Validate Exception Handling**: Proper hierarchy, error codes, global handlers
4. **Optimize Performance**: Database queries, async patterns, resource management
5. **Verify Code Quality**: SOLID principles, clean code, documentation
6. **Assess Test Coverage**: {{TEST_COVERAGE_THRESHOLD}}% for business logic, integration tests
7. **Check Configuration**: No hardcoded values, externalized secrets

**Note**: Coverage thresholds and quality metrics defined in technology-stack.md

---

## Review Framework

/* AI AGENT WORKFLOW:
 * 1. CONTEXT: Read technology-stack.md + pom.xml/build.gradle + list project structure
 * 2. VERSIONS: Compare project vs technology-stack.md (Java, Spring Boot, libraries)
 * 3. ARCHITECTURE: Verify controller→service→repository, check anti-patterns
 * 4. SECURITY: Check auth, password encoding, SQL injection, secrets, validation
 * 5. EXCEPTIONS: Verify BaseException hierarchy, GlobalExceptionHandler, error codes (XXX-NNN)
 * 6. QUALITY: Check complexity, SOLID, naming, duplication, JavaDoc
 * 7. TESTING: Check test files, coverage reports, AAA pattern, mocking
 * 8. CONFIG: Check application.yml, env configs, externalized secrets
 * 9. REPORT: List findings with severity, file:line, code evidence, fixes
 * 
 * REMEMBER: Base findings on actual code only. Cite file paths and line numbers.
 */

### Critical Focus Areas

**Architecture**: Clean layers (API→App→Domain→Infra), DDD, SOLID, design patterns, microservices
**Exceptions**: BaseException→Business/System, error codes (XXX-NNN), GlobalExceptionHandler, ErrorResponse
**Security**: OWASP Top 10, JWT/OAuth2, RBAC (@PreAuthorize), validation (@Valid), no SQL injection/XSS, BCrypt, secrets in Vault, HTTPS
**Performance**: Async/reactive, N+1 prevention, caching (Redis/Caffeine), pagination, connection pooling
**Quality**: SOLID/DRY/KISS, methods ≤30 lines, complexity <10, duplication <3%, JavaDoc
**Testing**: Coverage ≥90%, AAA pattern, Mockito, TestContainers, test independence
**Config**: Externalized (application.yml), env-specific profiles, no hardcoded secrets
**Logging**: SLF4J, levels (ERROR/WARN/INFO), parameterized, MDC correlation, no PII

---

## Code Organization & Naming

### Project Structure
```
src/main/java/{package}/
├── Application.java
├── config/          # SecurityConfig, DatabaseConfig
├── controller/      # REST endpoints + advice/GlobalExceptionHandler
├── service/         # Business logic (interface + impl/)
├── repository/      # Data access (JPA)
├── entity/          # JPA entities
├── dto/             # request/ + response/
├── exception/       # BaseException, Business/SystemException, ErrorResponse
├── mapper/          # Entity↔DTO (MapStruct)
├── security/        # JWT, filters
├── validator/       # Custom validators
└── util/            # Constants, helpers

src/main/resources/
├── application.yml
├── application-{dev,test,prod}.yml
└── db/migration/    # Flyway/Liquibase

src/test/java/{package}/
├── *Test.java       # Unit tests
└── *IT.java         # Integration tests
```
│   │   └── resources
│   │       ├── application.yml
│   │       ├── application-dev.yml
│   │       ├── application-test.yml
│   │       ├── application-prod.yml
│   │       ├── messages.properties          # Internationalization
│   │       ├── logback-spring.xml           # Logging config
│   │       └── db/migration/                # Flyway scripts
│   │           └── V1__initial_schema.sql
│   └── test
│       └── java/{{base_package}}/{{project}}
│           ├── controller/
│           ├── service/
│           ├── repository/
│           └── integration/
```

### Naming Conventions

```java
// ✅ Classes: PascalCase, nouns
public class CustomerService { }
public class OrderRepository { }

// ✅ Interfaces: PascalCase, no 'I' prefix
public interface PaymentProcessor { }

// ✅ Methods: camelCase, verbs
public void processPayment() { }
public Customer findCustomerById(Long id) { }
public boolean isActive() { }

// ✅ Variables: camelCase, nouns
private final String userEmailAddress;
private int currentPageNumber;

// ✅ Constants: UPPER_SNAKE_CASE
public static final int MAX_RETRY_ATTEMPTS = 3;
public static final String DEFAULT_ENCODING = "UTF-8";

// ✅ Packages: lowercase
package com.company.project.service;

// ✅ Enums: PascalCase for type, UPPER_CASE for values
public enum OrderStatus {
    PENDING, COMPLETED, CANCELLED
}
```

**Review Criteria:**
- ✅ Clear package structure with separation of concerns
- ✅ Consistent naming conventions across codebase
- ✅ No abbreviations except widely accepted (DTO, API, ID)
- ✅ Meaningful, searchable names
- ✅ Package depth <= 4 levels

---

## Exception Handling

/* Features: Hierarchical structure (BaseException→Business/System), unique error codes (XXX-NNN),
 * domain exceptions, GlobalExceptionHandler, i18n, structured ErrorResponse
 */

### Exception Hierarchy

```java
public abstract class BaseException extends RuntimeException {
    private final String errorCode;
    private final String messageKey;
    private final ErrorSeverity severity;
    private final transient Object[] messageArgs;
    // Constructor + getters
}

public class BusinessException extends BaseException { } // Recoverable
public class SystemException extends BaseException { }   // Unrecoverable

public class ValidationException extends BusinessException {
    private final List<ValidationError> validationErrors;
}

public class CustomerException extends BusinessException {
    public static final String CUSTOMER_NOT_FOUND = "CUS-001";
    public static final String CUSTOMER_ALREADY_EXISTS = "CUS-002";
}

public enum ErrorSeverity { INFO, WARNING, ERROR, FATAL; }
```

### Error Response & Global Handler

```java
@Builder @Data
public class ErrorResponse {
    private String errorCode, message, correlationId, path;
    private HttpStatus status;
    private LocalDateTime timestamp;
    private List<ValidationError> validationErrors;
}

@Data @AllArgsConstructor
public class ValidationError {
    private String field, code, message;
}

@RestControllerAdvice @Slf4j
public class GlobalExceptionHandler {
    @Autowired private MessageSource messageSource;

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusinessException(BusinessException ex, WebRequest req) {
        String msg = messageSource.getMessage(ex.getMessageKey(), ex.getMessageArgs(), LocaleContextHolder.getLocale());
        return ResponseEntity.badRequest().body(ErrorResponse.builder()
            .errorCode(ex.getErrorCode()).message(msg).status(HttpStatus.BAD_REQUEST)
            .correlationId(MDC.get("correlationId")).timestamp(LocalDateTime.now()).path(req.getDescription(false)).build());
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(ValidationException ex, WebRequest req) {
        return ResponseEntity.badRequest().body(ErrorResponse.builder()
            .errorCode(ex.getErrorCode()).message("Validation failed")
            .validationErrors(ex.getValidationErrors()).build());
    }

    @ExceptionHandler(SystemException.class)
    public ResponseEntity<ErrorResponse> handleSystemException(SystemException ex, WebRequest req) {
        log.error("System exception: {}", ex.getErrorCode(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ErrorResponse.builder()
            .errorCode(ex.getErrorCode()).message("Internal server error").build());
    }
}
```
            .status(HttpStatus.BAD_REQUEST)
            .correlationId(MDC.get("correlationId"))
            .timestamp(LocalDateTime.now())
            .validationErrors(ex.getValidationErrors())
            .path(request.getDescription(false))
            .build();
            
        return ResponseEntity.badRequest().body(error);
    }

    @ExceptionHandler(SystemException.class)
    public ResponseEntity<ErrorResponse> handleSystemException(
            SystemException ex,
            WebRequest request) {
        
        log.error("System exception: {} - {}", ex.getErrorCode(), ex.getMessage(), ex);
        
        ErrorResponse error = ErrorResponse.builder()
            .errorCode(ex.getErrorCode())
            .message("An internal error occurred")
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .correlationId(MDC.get("correlationId"))
            .timestamp(LocalDateTime.now())
            .path(request.getDescription(false))
            .build();
            
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(
            Exception ex,
            WebRequest request) {
        
        log.error("Unhandled exception", ex);
        
        ErrorResponse error = ErrorResponse.builder()
            .errorCode("SYS-999")
            .message("An unexpected error occurred")
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .correlationId(MDC.get("correlationId"))
            .timestamp(LocalDateTime.now())
            .path(request.getDescription(false))
            .build();
            
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
    }
}
```

### Error Messages (messages.properties)

```properties
# Customer domain
customer.CUS-001=Customer with ID {0} not found
customer.CUS-002=Customer with email {0} already exists
customer.CUS-003=Customer {0} is currently inactive

# Order domain
order.ORD-001=Order with ID {0} not found
order.ORD-002=Invalid order status transition from {0} to {1}
order.ORD-003=Order {0} has already been processed

# Validation
validation.failed=Validation failed for the provided data
```

### Usage Example

```java
@Service
@Slf4j
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {
    private final CustomerRepository repository;

    @Override
    @Transactional
    public CustomerDto createCustomer(CreateCustomerRequest request) {
        log.info("Creating customer with email: {}", request.getEmail());
        
        try {
            // Check for duplicate
            Optional<Customer> existing = repository.findByEmail(request.getEmail());
            if (existing.isPresent()) {
                throw new CustomerException(
                    CustomerException.CUSTOMER_ALREADY_EXISTS,
                    request.getEmail()
                );
            }
            
            // Create customer
            Customer customer = new Customer(request.getName(), request.getEmail());
            Customer saved = repository.save(customer);
            
            log.info("Successfully created customer with ID: {}", saved.getId());
            return CustomerDto.fromEntity(saved);
            
        } catch (CustomerException e) {
            throw e; // Re-throw business exceptions
        } catch (DataAccessException e) {
            log.error("Database error creating customer: {}", request.getEmail(), e);
            throw new SystemException("SYS-001", "database.error");
        } catch (Exception e) {
            log.error("Unexpected error creating customer: {}", request.getEmail(), e);
            throw new SystemException("SYS-999", "unexpected.error");
        }
    }
}
```

**Review Criteria:**
- ✅ Hierarchical exception structure (BaseException → Business/System)
- ✅ Unique error codes for all exceptions
- ✅ Domain-specific exception classes
- ✅ Global exception handler with @RestControllerAdvice
- ✅ Standardized ErrorResponse structure
- ✅ Internationalization support (MessageSource)
- ✅ No swallowed exceptions or empty catch blocks
- ✅ Proper exception logging with context
- ✅ Correlation IDs for tracing
- ✅ HTTP status codes match error types

---

## Security Guidelines

/* OWASP Top 10 compliance: Authentication (JWT/OAuth2), Authorization (RBAC),
 * Input Validation, Data Protection (encryption), Transport Security (HTTPS/TLS)
 */

### Authentication & JWT Security

```java
/**
 * Spring Security configuration with JWT
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    
    @Autowired
    private JwtAuthenticationFilter jwtFilter;
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
            .csrf(csrf -> csrf.disable()) // Use JWT instead
            .sessionManagement(session -> 
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/v1/auth/**", "/api/v1/public/**").permitAll()
                .requestMatchers("/api/v1/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
            .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12); // Work factor of 12
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}

/**
 * JWT Token Provider
 */
@Component
@Slf4j
public class JwtTokenProvider {
    
    @Value("${jwt.secret}")
    private String jwtSecret;
    
    @Value("${jwt.expiration:3600000}") // 1 hour default
    private long jwtExpiration;
    
    public String generateToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("roles", userDetails.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .collect(Collectors.toList()));
            
        return Jwts.builder()
            .setClaims(claims)
            .setSubject(userDetails.getUsername())
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))
            .signWith(Keys.hmacShaKeyFor(jwtSecret.getBytes()), SignatureAlgorithm.HS512)
            .compact();
    }
    
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(jwtSecret.getBytes()))
                .build()
                .parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            log.error("Invalid JWT token: {}", e.getMessage());
            return false;
        }
    }
    
    public String getUsernameFromToken(String token) {
        Claims claims = Jwts.parserBuilder()
            .setSigningKey(Keys.hmacShaKeyFor(jwtSecret.getBytes()))
            .build()
            .parseClaimsJws(token)
            .getBody();
        return claims.getSubject();
    }
}
```

### Input Validation

```java
@Data
public class CreateCustomerRequest {
    @NotBlank @Size(min=2, max=100) @Pattern(regexp="^[a-zA-Z\\s]+$")
    private String name;
    
    @NotBlank @Email
    private String email;
    
    @NotBlank @ValidPassword // Custom annotation
    private String password;
}

@Constraint(validatedBy = PasswordConstraintValidator.class)
public @interface ValidPassword { }

@Component
public class PasswordConstraintValidator implements ConstraintValidator<ValidPassword, String> {
    public boolean isValid(String password, ConstraintValidatorContext ctx) {
        return password != null && password.length() >= 12 
            && password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).+$");
    }
}

@RestController @Validated
public class CustomerController {
    @PostMapping
    public ResponseEntity<CustomerResponse> create(@Valid @RequestBody CreateCustomerRequest req) {
        return ResponseEntity.status(CREATED).body(customerService.createCustomer(req));
    }
}
```

### SQL Injection Prevention

```java
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // ✅ JPA method query (type-safe)
    Optional<Customer> findByEmail(String email);
    
    // ✅ Named parameters in JPQL
    @Query("SELECT c FROM Customer c WHERE c.email = :email AND c.status = :status")
    Optional<Customer> findByEmailAndStatus(@Param("email") String email, @Param("status") String status);
    
    // ✅ Native query with parameters
    @Query(value = "SELECT * FROM customers WHERE email = :email", nativeQuery = true)
    Optional<Customer> findByEmailNative(@Param("email") String email);
}

// ❌ NEVER: String concatenation (SQL injection risk!)
// String sql = "SELECT * FROM customers WHERE email = '" + email + "'";
```
    
    // ✅ GOOD - Named parameters in JPQL
    @Query("SELECT c FROM Customer c WHERE c.email = :email AND c.status = :status")
    Optional<Customer> findByEmailAndStatus(
        @Param("email") String email,
        @Param("status") String status);
    
    // ✅ GOOD - Native query with parameters
    @Query(value = "SELECT * FROM customers WHERE email = :email", nativeQuery = true)
    Optional<Customer> findByEmailNative(@Param("email") String email);
}

// ❌ BAD - String concatenation (SQL injection risk!)
@Service
public class BadCustomerService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    public Customer findByEmail(String email) {
        // NEVER DO THIS!
        String sql = "SELECT * FROM customers WHERE email = '" + email + "'";
        return jdbcTemplate.queryForObject(sql, Customer.class);
    }
}

// ✅ GOOD - PreparedStatement with parameters
@Service
public class GoodCustomerService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    public Customer findByEmail(String email) {
        String sql = "SELECT * FROM customers WHERE email = ?";
        return jdbcTemplate.queryForObject(sql, 
            new Object[]{email}, 
            new CustomerRowMapper());
    }
}
```

### XSS Prevention

```java
/**
 * Output encoding and Content Security Policy
 */
@Configuration
public class SecurityHeadersConfig implements WebMvcConfigurer {
    
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new SecurityHeadersInterceptor());
    }
}

public class SecurityHeadersInterceptor implements HandlerInterceptor {
    
    @Override
    public boolean preHandle(HttpServletRequest request, 
                           HttpServletResponse response, 
                           Object handler) {
        // Content Security Policy
        response.setHeader("Content-Security-Policy", 
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'");
        
        // XSS Protection
        response.setHeader("X-XSS-Protection", "1; mode=block");
        
        // Frame Options
        response.setHeader("X-Frame-Options", "DENY");
        
        // Content Type Options
        response.setHeader("X-Content-Type-Options", "nosniff");
        
        // HSTS
        response.setHeader("Strict-Transport-Security", 
            "max-age=31536000; includeSubDomains; preload");
        
        return true;
    }
}

/**
 * Sanitize user input before storing
 */
@Service
public class SanitizationService {
    
    public String sanitizeHtml(String input) {
        if (input == null) return null;
        
        // Use a library like OWASP Java HTML Sanitizer
        PolicyFactory policy = new HtmlPolicyBuilder()
            .allowElements("p", "br", "b", "i", "u")
            .toFactory();
            
        return policy.sanitize(input);
    }
}
```

### Data Encryption & Masking

```java
@Configuration
public class EncryptionConfig {
    @Bean
    public StringEncryptor stringEncryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        encryptor.setPassword(System.getenv("ENCRYPTION_KEY"));
        encryptor.setAlgorithm("PBEWITHHMACSHA512ANDAES_256");
        return encryptor;
    }
}

@Converter
public class AttributeEncryptor implements AttributeConverter<String, String> {
    @Autowired private StringEncryptor encryptor;
    public String convertToDatabaseColumn(String attr) { return encryptor.encrypt(attr); }
    public String convertToEntityAttribute(String data) { return encryptor.decrypt(data); }
}

@Entity
public class Customer {
    @Convert(converter = AttributeEncryptor.class)
    private String socialSecurityNumber; // Encrypted at rest
    
    @JsonSerialize(using = SensitiveDataSerializer.class)
    private String creditCardNumber; // Masked in responses (****1234)
}
```

### Rate Limiting

```java
/**
 * Rate limiting with Bucket4j
 */
@Component
public class RateLimitInterceptor implements HandlerInterceptor {
    
    private final Map<String, Bucket> cache = new ConcurrentHashMap<>();
    
    @Override
    public boolean preHandle(HttpServletRequest request, 
                           HttpServletResponse response, 
                           Object handler) {
        String key = request.getRemoteAddr(); // Or use API key
        Bucket bucket = resolveBucket(key);
        
        if (bucket.tryConsume(1)) {
            return true;
        } else {
            response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
            return false;
        }
    }
    
    private Bucket resolveBucket(String key) {
        return cache.computeIfAbsent(key, k -> {
            // 100 requests per minute
            Bandwidth limit = Bandwidth.classic(100, Refill.intervally(100, Duration.ofMinutes(1)));
            return Bucket.builder()
                .addLimit(limit)
                .build();
        });
    }
}
```

**Review Criteria:**
- ✅ Spring Security configured with proper authentication
- ✅ JWT or OAuth2 implementation for stateless auth
- ✅ Password hashing with BCrypt (work factor >= 12)
- ✅ Input validation with Bean Validation (JSR 380)
- ✅ SQL injection prevention (parameterized queries only)
- ✅ XSS prevention (output encoding, CSP headers)
- ✅ CSRF protection enabled
- ✅ No hardcoded secrets (use environment variables or Vault)
- ✅ Sensitive data encrypted at rest
- ✅ Security headers configured (HSTS, X-Frame-Options, etc.)
- ✅ HTTPS enforcement
- ✅ Rate limiting implemented
- ✅ Dependency vulnerability scanning (OWASP Dependency-Check)

---

## Technology Stack

/* VALIDATION: (1) Read technology-stack.md for required versions
 * (2) Read pom.xml/build.gradle for actual versions (3) Compare and report mismatches
 * 
 * REPORT FORMAT:
 * Finding: [Dependency] version mismatch
 * Expected: [version from technology-stack.md] | Actual: [version from build file]
 * Location: [file:line] | Evidence: [code snippet]
 * 
 * DO NOT: Report without reading files, assume versions, invent line numbers, hallucinate dependencies
 */
 * TECHNOLOGY STACK REFERENCE
 * =============================================================================
 *
 * IMPORTANT: This section references the technology-stack.md document for all
 * version numbers, library versions, and configurations. The technology stack
 * document is the single source of truth for:
 *
 * 1. Core Technologies (Java, Spring Boot, Maven/Gradle)
 * 2. Database Technologies (MySQL, PostgreSQL, Hibernate, Flyway)
 * 3. Common Libraries (Lombok, MapStruct, Jackson, SLF4J)
 * 4. Testing Frameworks (JUnit, Mockito, TestContainers)
 * 5. Security Libraries (Spring Security, JWT, OAuth2)
 * 6. Documentation & Monitoring (Swagger, Actuator, Micrometer)
 *
 * DO NOT HARDCODE VERSIONS IN THIS DOCUMENT.
 *
 * When reviewing code or generating code:
 * 1. Always refer to technology-stack.md for current versions
 * 2. Use dynamic placeholders: {{JAVA_VERSION}}, {{SPRING_BOOT_VERSION}}, etc.
 * 3. Validate that project dependencies match the approved technology stack
 * 4. Check for outdated or deprecated library versions
 * 5. Ensure compatibility between library versions
 *
 * =============================================================================
 */

### Technology Stack Reference

**⚠️ IMPORTANT**: All technology versions, library versions, and configurations are
maintained in the **technology-stack.md** document. This includes:

#### Core Technologies
- **Java**: {{JAVA_VERSION}} (refer to technology-stack.md)
- **Spring Boot**: {{SPRING_BOOT_VERSION}} (refer to technology-stack.md)
- **Spring Framework**: {{SPRING_FRAMEWORK_VERSION}} (managed by Spring Boot)
- **Maven**: {{MAVEN_VERSION}} (refer to technology-stack.md)
- **Gradle**: {{GRADLE_VERSION}} (optional alternative)

#### Database Technologies
- **MySQL**: {{MYSQL_VERSION}} (refer to technology-stack.md)
- **PostgreSQL**: {{POSTGRESQL_VERSION}} (alternative)
- **Spring Data JPA**: {{SPRING_DATA_JPA_VERSION}} (refer to technology-stack.md)
- **Hibernate**: {{HIBERNATE_VERSION}} (refer to technology-stack.md)
- **Flyway**: {{FLYWAY_VERSION}} (optional migration tool)
- **Liquibase**: {{LIQUIBASE_VERSION}} (alternative migration tool)

#### Common Libraries
- **Lombok**: {{LOMBOK_VERSION}} (refer to technology-stack.md)
- **MapStruct**: {{MAPSTRUCT_VERSION}} (refer to technology-stack.md)
- **Jackson**: {{JACKSON_VERSION}} (refer to technology-stack.md)
- **SLF4J**: {{SLF4J_VERSION}} (refer to technology-stack.md)
- **Logback**: {{LOGBACK_VERSION}} (refer to technology-stack.md)

#### Testing Frameworks
- **JUnit Jupiter**: {{JUNIT_VERSION}} (refer to technology-stack.md)
- **Mockito**: {{MOCKITO_VERSION}} (refer to technology-stack.md)
- **AssertJ**: {{ASSERTJ_VERSION}} (optional)
- **TestContainers**: {{TESTCONTAINERS_VERSION}} (refer to technology-stack.md)
- **Rest Assured**: {{REST_ASSURED_VERSION}} (optional)

#### Security Libraries
- **Spring Security**: {{SPRING_SECURITY_VERSION}} (refer to technology-stack.md)
- **JWT (JJWT)**: {{JJWT_VERSION}} (refer to technology-stack.md)
- **Spring Security OAuth2**: {{SPRING_SECURITY_OAUTH2_VERSION}} (optional)
- **Passay**: {{PASSAY_VERSION}} (password validation)
- **Jasypt**: {{JASYPT_VERSION}} (encryption)

#### Documentation & Monitoring
- **SpringDoc OpenAPI**: {{SPRINGDOC_VERSION}} (refer to technology-stack.md)
- **Spring Actuator**: {{SPRING_ACTUATOR_VERSION}} (refer to technology-stack.md)
- **Micrometer**: {{MICROMETER_VERSION}} (refer to technology-stack.md)
- **Prometheus**: Client library (metrics export)

### Version Validation Rules

When reviewing code, validate:

1. **Version Compatibility**
   ```xml
   <!-- Example: Check pom.xml versions match technology-stack.md -->
   <java.version>{{JAVA_VERSION}}</java.version>
   <spring-boot.version>{{SPRING_BOOT_VERSION}}</spring-boot.version>
   ```

2. **Dependency Management**
   - All dependencies should be listed in technology-stack.md
   - No unlisted or unapproved libraries
   - Check for security vulnerabilities in dependencies

3. **Version Consistency**
   - Spring Boot version matches across all modules
   - Compatible library versions (e.g., Spring Security with Spring Boot)
   - No version conflicts in transitive dependencies

### Review Checklist for Technology Stack

- [ ] Java version matches {{JAVA_VERSION}} from technology-stack.md
- [ ] Spring Boot version matches {{SPRING_BOOT_VERSION}}
- [ ] All dependencies listed in technology-stack.md
- [ ] No deprecated or end-of-life versions
- [ ] Security vulnerabilities checked (OWASP Dependency-Check)
- [ ] Library versions are compatible with each other
- [ ] Build tool version matches (Maven {{MAVEN_VERSION}} or Gradle {{GRADLE_VERSION}})
- [ ] Testing frameworks use approved versions
- [ ] Security libraries use approved versions
- [ ] Monitoring and documentation tools configured correctly

**Note**: For complete technology stack details, version numbers, and "Required" flags,
always refer to the **technology-stack.md** document.

---

## Quality Metrics & Tools

### Static Analysis Tools

/*
 * =============================================================================
 * STATIC ANALYSIS TOOL CONFIGURATION
 * =============================================================================
 *
 * IMPORTANT: Plugin versions should be validated against technology-stack.md
 * for compatibility and security updates.
 *
 * All version numbers in these examples use dynamic placeholders.
 * Refer to technology-stack.md for actual version numbers.
 *
 * =============================================================================
 */

```xml
<!-- SonarQube Maven Plugin -->
<plugin>
    <groupId>org.sonarsource.scanner.maven</groupId>
    <artifactId>sonar-maven-plugin</artifactId>
    <version>{{SONAR_MAVEN_PLUGIN_VERSION}}</version>
</plugin>

<!-- Checkstyle -->
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-checkstyle-plugin</artifactId>
    <version>{{CHECKSTYLE_PLUGIN_VERSION}}</version>
    <configuration>
        <configLocation>google_checks.xml</configLocation>
    </configuration>
</plugin>

<!-- SpotBugs -->
<plugin>
    <groupId>com.github.spotbugs</groupId>
    <artifactId>spotbugs-maven-plugin</artifactId>
    <version>{{SPOTBUGS_PLUGIN_VERSION}}</version>
</plugin>

<!-- OWASP Dependency Check -->
<plugin>
    <groupId>org.owasp</groupId>
    <artifactId>dependency-check-maven</artifactId>
    <version>{{OWASP_DEPENDENCY_CHECK_VERSION}}</version>
</plugin>

<!-- JaCoCo Coverage -->
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>{{JACOCO_PLUGIN_VERSION}}</version>
    <executions>
        <execution>
            <goals>
                <goal>prepare-agent</goal>
            </goals>
        </execution>
        <execution>
            <id>report</id>
            <phase>test</phase>
            <goals>
                <goal>report</goal>
            </goals>
        </execution>
    </executions>
</plugin>
/* Refer to technology-stack.md for current plugin versions */

### Quality Metrics Thresholds

/* Thresholds from technology-stack.md. Adjust per project but align with org standards. */

```yaml
quality_gates:
  code_coverage:
    business_logic: >= {{COVERAGE_BUSINESS_LOGIC_THRESHOLD}}%  # Default: 90%
    overall: >= {{COVERAGE_OVERALL_THRESHOLD}}%                # Default: 90%
  
  cyclomatic_complexity:
    per_method: < {{COMPLEXITY_METHOD_THRESHOLD}}              # Default: 10
    per_class: < {{COMPLEXITY_CLASS_THRESHOLD}}                # Default: 50
  
  code_duplication:
    lines: < {{DUPLICATION_LINES_THRESHOLD}}%                  # Default: 3%
    blocks: < {{DUPLICATION_BLOCKS_THRESHOLD}}%                # Default: 5%
  
  technical_debt:
    ratio: < {{TECH_DEBT_RATIO_THRESHOLD}}%                    # Default: 5%
    maintainability_rating: >= {{MAINTAINABILITY_RATING}}      # Default: B
  
  security:
    critical_vulnerabilities: {{SECURITY_CRITICAL_THRESHOLD}}  # Default: 0
    high_vulnerabilities: {{SECURITY_HIGH_THRESHOLD}}          # Default: 0
    security_hotspots_reviewed: {{SECURITY_HOTSPOT_THRESHOLD}}% # Default: 100%
  
  reliability:
    critical_bugs: {{RELIABILITY_CRITICAL_THRESHOLD}}          # Default: 0
    high_bugs: {{RELIABILITY_HIGH_THRESHOLD}}                  # Default: 0
    reliability_rating: >= {{RELIABILITY_RATING}}              # Default: A
  
  code_smells:
    critical: {{CODE_SMELL_CRITICAL_THRESHOLD}}                # Default: 0
    major: < {{CODE_SMELL_MAJOR_THRESHOLD}}                    # Default: 10
```

**Configuration Notes**:
- Threshold values should be defined in project configuration or technology-stack.md
- These values represent recommended minimums for production-ready code
- Stricter thresholds may be required for critical systems (financial, healthcare, etc.)
- Refer to organizational quality standards for specific requirements

---

## CI/CD Integration

### GitHub Actions Pipeline

/* All versions use {{PLACEHOLDERS}} - resolve from technology-stack.md */

```yaml
name: Java Code Review

on:
  pull_request:
    branches: [ main, develop ]
  push:
    branches: [ main ]

jobs:
  code-review:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
      with:
        fetch-depth: 0  # For SonarQube
      
    - name: Set up JDK
      uses: actions/setup-java@v3
      with:
        java-version: '{{JAVA_VERSION}}'  # From technology-stack.md
        distribution: 'temurin'
        cache: maven
        
    - name: Run Maven Build
      run: mvn clean verify
      
    - name: Run Unit Tests
      run: mvn test
      
    - name: Run Integration Tests
      run: mvn verify -P integration-tests
      
    - name: Generate Coverage Report
      run: mvn jacoco:report
      
    - name: Upload Coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        files: ./target/site/jacoco/jacoco.xml
        flags: unittests
        name: codecov-umbrella
        
    - name: Run SonarQube Analysis
      env:
        SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}
        SONAR_HOST_URL: ${{ secrets.SONAR_HOST_URL }}
      run: |
        mvn sonar:sonar \
          -Dsonar.projectKey=${{ secrets.SONAR_PROJECT_KEY }} \
          -Dsonar.host.url=${{ secrets.SONAR_HOST_URL }} \
          -Dsonar.login=${{ secrets.SONAR_TOKEN }}
          
    - name: Run Checkstyle
      run: mvn checkstyle:check
      
    - name: Run SpotBugs
      run: mvn spotbugs:check
      
    - name: Run Security Scan (OWASP Dependency Check)
      run: mvn org.owasp:dependency-check-maven:check
      
    - name: Validate Quality Gates
      env:
        COVERAGE_THRESHOLD: '{{COVERAGE_BUSINESS_LOGIC_THRESHOLD}}'  # From technology-stack.md
      run: |
        # Check SonarQube quality gate status
        QUALITY_GATE=$(curl -s -u ${{ secrets.SONAR_TOKEN }}: \
          "${{ secrets.SONAR_HOST_URL }}/api/qualitygates/project_status?projectKey=${{ secrets.SONAR_PROJECT_KEY }}" \
          | jq -r '.projectStatus.status')
          
        if [ "$QUALITY_GATE" != "OK" ]; then
          echo "Quality gate failed. Deployment blocked."
          exit 1
        fi
        
        # Check coverage threshold (from technology-stack.md)
        COVERAGE=$(mvn jacoco:report | grep -oP 'Total.*?([0-9]+)%' | grep -oP '[0-9]+' | tail -1)
        if [ "$COVERAGE" -lt "$COVERAGE_THRESHOLD" ]; then
          echo "Code coverage ($COVERAGE%) below threshold ($COVERAGE_THRESHOLD%). Deployment blocked."
          exit 1
        fi
```

**Note**: Replace all {{PLACEHOLDER}} values with actual versions from technology-stack.md

---

## Implementation Checklist

/*
 * =============================================================================
 * IMPLEMENTATION CHECKLIST
 * =============================================================================
 *
 * IMPORTANT: All version references should be validated against technology-stack.md
 * before marking items as complete.
 *
 * Use this checklist during:
 * 1. Initial project setup
 * 2. Code review process
 * 3. Pre-deployment validation
 * 4. Quality gate enforcement
 *
 * =============================================================================
 */

### Pre-Review Setup
- [ ] **Project Structure**: Maven/Gradle configured per technology-stack.md
- [ ] **Java Version**: {{JAVA_VERSION}} configured (verify in pom.xml/build.gradle)
- [ ] **Spring Boot Version**: {{SPRING_BOOT_VERSION}} configured
- [ ] **Dependencies**: All required libraries from technology-stack.md added
- [ ] **Configuration**: application.yml created with environment profiles
- [ ] **Database**: Migration scripts (Flyway/Liquibase per technology-stack.md) configured
- [ ] **Security**: Spring Security {{SPRING_SECURITY_VERSION}} configured
- [ ] **Testing**: JUnit {{JUNIT_VERSION}}, Mockito {{MOCKITO_VERSION}}, TestContainers {{TESTCONTAINERS_VERSION}} configured

### Code Organization
- [ ] Clear package structure (controller, service, repository, entity, dto, exception)
- [ ] Separation of concerns enforced
- [ ] No circular dependencies
- [ ] Package depth <= 4 levels
- [ ] Test structure mirrors main structure

### Exception Handling
- [ ] Base exception hierarchy implemented
- [ ] Domain-specific exceptions created
- [ ] Unique error codes defined
- [ ] Global exception handler (@RestControllerAdvice)
- [ ] ErrorResponse structure standardized
- [ ] Internationalization support (messages.properties)
- [ ] No empty catch blocks or swallowed exceptions

### Security
- [ ] Spring Security configured
- [ ] Authentication mechanism implemented (JWT/OAuth2)
- [ ] Authorization rules defined (@PreAuthorize, @Secured)
- [ ] Input validation with Bean Validation (JSR 380)
- [ ] SQL injection prevention (no string concatenation in queries)
- [ ] XSS prevention (CSP headers, output encoding)
- [ ] CSRF protection enabled
- [ ] Password hashing with BCrypt (work factor >= 12)
- [ ] No hardcoded secrets
- [ ] Sensitive data encrypted
- [ ] Security headers configured
- [ ] HTTPS enforced
- [ ] Rate limiting implemented

### Performance
- [ ] Async patterns used (CompletableFuture, @Async)
- [ ] N+1 queries prevented (fetch joins, @EntityGraph)
- [ ] Database connection pooling configured
- [ ] Caching strategy implemented
- [ ] Pagination for large datasets
- [ ] Bulk operations for batch processing
- [ ] Resource management (try-with-resources)

### Testing
- [ ] Unit test coverage >= {{COVERAGE_BUSINESS_LOGIC_THRESHOLD}}% for business logic (from technology-stack.md)
- [ ] Integration tests for critical workflows
- [ ] AAA pattern followed (Arrange-Act-Assert)
- [ ] Test names meaningful (shouldDoSomethingWhenCondition)
- [ ] Mocking with Mockito {{MOCKITO_VERSION}}
- [ ] TestContainers {{TESTCONTAINERS_VERSION}} for database tests
- [ ] Tests are independent and repeatable

### Configuration
- [ ] All secrets externalized (environment variables, Vault)
- [ ] Environment-specific property files (application-{profile}.yml)
- [ ] Configuration validation (@ConfigurationProperties, @Validated)
- [ ] No hardcoded values in source code

### Logging
- [ ] SLF4J {{SLF4J_VERSION}} used for logging
- [ ] Appropriate log levels (ERROR, WARN, INFO, DEBUG, TRACE)
- [ ] Parameterized logging (no string concatenation)
- [ ] MDC for correlation IDs
- [ ] No sensitive data in logs (passwords, tokens, PII)
- [ ] Structured logging format (JSON)

### Code Quality
- [ ] SOLID principles followed
- [ ] Clean code principles (DRY, KISS, YAGNI)
- [ ] Method size <= 20-30 lines
- [ ] Cyclomatic complexity < {{COMPLEXITY_METHOD_THRESHOLD}} per method
- [ ] Code duplication < {{DUPLICATION_LINES_THRESHOLD}}%
- [ ] JavaDoc for public APIs
- [ ] Meaningful naming conventions

### Static Analysis
- [ ] SonarQube configured with quality gates
- [ ] Checkstyle rules enforced
- [ ] SpotBugs configured for bug detection
- [ ] OWASP Dependency Check enabled
- [ ] JaCoCo coverage reporting configured
- [ ] All quality gates passing per thresholds in technology-stack.md

### CI/CD
- [ ] Build pipeline configured with Maven {{MAVEN_VERSION}} or Gradle {{GRADLE_VERSION}}
- [ ] Automated tests in pipeline (unit + integration)
- [ ] Code quality checks automated (SonarQube, Checkstyle, SpotBugs)
- [ ] Security scans automated (OWASP Dependency-Check)
- [ ] Quality gates enforced (coverage >= {{COVERAGE_BUSINESS_LOGIC_THRESHOLD}}%)
- [ ] Deployment blocked on failures
- [ ] Java {{JAVA_VERSION}} configured in pipeline

### Technology Stack Validation
- [ ] All versions match technology-stack.md specifications
- [ ] No deprecated libraries or end-of-life versions
- [ ] All required libraries present (marked "Yes" in technology-stack.md)
- [ ] Optional libraries justified and documented
- [ ] Dependency conflicts resolved
- [ ] Security vulnerabilities addressed (OWASP scan clean)

---

## Version History

- **2.0.0** (November 25, 2025)
  - **MAJOR UPDATE**: Made all versions and configurations dynamic
  - All technology versions now reference technology-stack.md
  - Replaced hardcoded versions with dynamic placeholders ({{JAVA_VERSION}}, {{SPRING_BOOT_VERSION}}, etc.)
  - Added comprehensive technology stack reference section
  - Updated CI/CD pipeline examples with dynamic version placeholders
  - Enhanced quality metrics with configurable thresholds
  - Added technology stack validation checklist
  - Integrated exception handling guidelines comprehensively
  - Added detailed security guidelines (OWASP Top 10 compliance)
  - Incorporated coding standards and clean code principles
  - Enhanced review framework with detailed focus areas
  - Added comprehensive code organization and naming conventions
  - Expanded implementation checklist with dynamic version references
  
- **1.0.0** (November 25, 2025)
  - Initial version with basic review guidelines

---

## Dynamic Placeholders Reference

/* PLACEHOLDER RESOLUTION:
 * {{PLACEHOLDER}} = read from technology-stack.md (NOT hardcoded values)
 * 
 * Steps: (1) Read technology-stack.md (2) Extract version (3) Use in review
 * 
 * Example: {{JAVA_VERSION}} in doc → Read tech-stack.md → Find "Java: 17" → Report "Java 17"
 * ❌ BAD: "Use {{JAVA_VERSION}}" | ✅ GOOD: "Use Java 17 (from technology-stack.md)"
 */

**Resolve all placeholders from technology-stack.md:**

### Core Technology Versions
- `{{JAVA_VERSION}}` - Java version (e.g., 17)
- `{{SPRING_BOOT_VERSION}}` - Spring Boot version (e.g., 3.1.5)
- `{{SPRING_FRAMEWORK_VERSION}}` - Spring Framework version (e.g., 6.0.13)
- `{{MAVEN_VERSION}}` - Maven version (e.g., 3.9.5)
- `{{GRADLE_VERSION}}` - Gradle version (e.g., 8.4)

### Database Versions
- `{{MYSQL_VERSION}}` - MySQL version (e.g., 8.0.x)
- `{{POSTGRESQL_VERSION}}` - PostgreSQL version (e.g., 15.x)
- `{{HIBERNATE_VERSION}}` - Hibernate version (e.g., 6.2.13.Final)
- `{{SPRING_DATA_JPA_VERSION}}` - Spring Data JPA version
- `{{FLYWAY_VERSION}}` - Flyway version (e.g., 9.22.3)
- `{{LIQUIBASE_VERSION}}` - Liquibase version (e.g., 4.23.2)

### Library Versions
- `{{LOMBOK_VERSION}}` - Lombok version (e.g., 1.18.30)
- `{{MAPSTRUCT_VERSION}}` - MapStruct version (e.g., 1.5.5.Final)
- `{{JACKSON_VERSION}}` - Jackson version (e.g., 2.15.3)
- `{{SLF4J_VERSION}}` - SLF4J version (e.g., 2.0.9)
- `{{LOGBACK_VERSION}}` - Logback version (e.g., 1.4.11)

### Testing Framework Versions
- `{{JUNIT_VERSION}}` - JUnit Jupiter version (e.g., 5.10.0)
- `{{MOCKITO_VERSION}}` - Mockito version (e.g., 5.6.0)
- `{{ASSERTJ_VERSION}}` - AssertJ version (e.g., 3.24.2)
- `{{TESTCONTAINERS_VERSION}}` - TestContainers version (e.g., 1.19.1)
- `{{REST_ASSURED_VERSION}}` - Rest Assured version (e.g., 5.3.2)

### Security Library Versions
- `{{SPRING_SECURITY_VERSION}}` - Spring Security version (e.g., 6.1.5)
- `{{JJWT_VERSION}}` - JJWT version (e.g., 0.12.3)
- `{{SPRING_SECURITY_OAUTH2_VERSION}}` - Spring Security OAuth2 version
- `{{PASSAY_VERSION}}` - Passay version (e.g., 1.6.3)
- `{{JASYPT_VERSION}}` - Jasypt version (e.g., 1.9.3)

### Monitoring & Documentation Versions
- `{{SPRINGDOC_VERSION}}` - SpringDoc OpenAPI version (e.g., 2.2.0)
- `{{SPRING_ACTUATOR_VERSION}}` - Spring Actuator version
- `{{MICROMETER_VERSION}}` - Micrometer version (e.g., 1.11.5)

### Build Plugin Versions
- `{{SONAR_MAVEN_PLUGIN_VERSION}}` - SonarQube Maven Plugin version
- `{{CHECKSTYLE_PLUGIN_VERSION}}` - Checkstyle Plugin version
- `{{SPOTBUGS_PLUGIN_VERSION}}` - SpotBugs Plugin version
- `{{OWASP_DEPENDENCY_CHECK_VERSION}}` - OWASP Dependency Check version
- `{{JACOCO_PLUGIN_VERSION}}` - JaCoCo Plugin version

### Quality Thresholds
- `{{TEST_COVERAGE_THRESHOLD}}` - Overall test coverage threshold (e.g., 90)
- `{{COVERAGE_BUSINESS_LOGIC_THRESHOLD}}` - Business logic coverage (e.g., 90)
- `{{COVERAGE_OVERALL_THRESHOLD}}` - Overall coverage (e.g., 90)
- `{{COMPLEXITY_METHOD_THRESHOLD}}` - Max cyclomatic complexity per method (e.g., 10)
- `{{COMPLEXITY_CLASS_THRESHOLD}}` - Max cyclomatic complexity per class (e.g., 50)
- `{{DUPLICATION_LINES_THRESHOLD}}` - Max code duplication percentage (e.g., 3)
- `{{DUPLICATION_BLOCKS_THRESHOLD}}` - Max block duplication percentage (e.g., 5)
- `{{TECH_DEBT_RATIO_THRESHOLD}}` - Max technical debt ratio (e.g., 5)
- `{{MAINTAINABILITY_RATING}}` - Minimum maintainability rating (e.g., B)
- `{{SECURITY_CRITICAL_THRESHOLD}}` - Max critical vulnerabilities (e.g., 0)
- `{{SECURITY_HIGH_THRESHOLD}}` - Max high vulnerabilities (e.g., 0)
- `{{SECURITY_HOTSPOT_THRESHOLD}}` - Security hotspots reviewed percentage (e.g., 100)
- `{{RELIABILITY_CRITICAL_THRESHOLD}}` - Max critical bugs (e.g., 0)
- `{{RELIABILITY_HIGH_THRESHOLD}}` - Max high bugs (e.g., 0)
- `{{RELIABILITY_RATING}}` - Minimum reliability rating (e.g., A)
- `{{CODE_SMELL_CRITICAL_THRESHOLD}}` - Max critical code smells (e.g., 0)
- `{{CODE_SMELL_MAJOR_THRESHOLD}}` - Max major code smells (e.g., 10)

---

This comprehensive review guidelines document ensures consistent, thorough code reviews that prepare Java applications for production deployment with confidence in quality, security, maintainability, and compliance with enterprise standards.

**All versions and configurations are managed dynamically through technology-stack.md, ensuring a single source of truth and easy maintenance.**

---

## FINAL CHECKLIST FOR AI AGENTS

### ✅ Data Integrity
- [ ] All versions from technology-stack.md (not assumptions)
- [ ] All findings cite file:line with code evidence
- [ ] No placeholder values ({{...}}) left unresolved in report

### ✅ Evidence & Completeness
- [ ] Every issue has: Category, Severity, File:Line, Code Evidence
- [ ] All workflow steps completed (versions, architecture, security, exceptions, quality, tests, config)
- [ ] No hallucinated code - all findings verified in actual files

### ✅ Accuracy
- [ ] Framework usage verified in dependencies
- [ ] Error codes match XXX-NNN pattern
- [ ] Test coverage from actual reports

### 🚫 Avoid
- ❌ Reporting "{{JAVA_VERSION}}" instead of actual version
- ❌ Citing template code as project findings
- ❌ Inventing line numbers or files
- ❌ Assuming frameworks without checking
- ❌ Using default thresholds vs technology-stack.md values

### 📋 Report Structure
```markdown
# Review Report
## Executive Summary
Total: [N] | Critical: [N] | High: [N] | Medium: [N] | Low: [N]

## Technology Stack Validation
[Compare project vs technology-stack.md]

## Findings
### [Issue Title]
**Category**: Security/Architecture/Quality | **Severity**: Critical/High/Medium/Low
**File**: [path:line] | **Evidence**: ```java [code] ```
**Issue**: [description] | **Impact**: [consequences]
**Fix**: [specific solution] | **Reference**: [guidelines section]
```

---

**END OF GUIDELINES**
