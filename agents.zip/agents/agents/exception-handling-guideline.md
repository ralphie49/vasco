# Exception Handling Guidelines for Java Applications
> Version: 1.0.0  
> Created: October 12, 2025  
> Last Updated: October 12, 2025  
> Author: Java Architecture Team

/*
 * =============================================================================
 * COMPREHENSIVE EXCEPTION HANDLING GUIDELINES FOR ENTERPRISE JAVA APPLICATIONS
 * =============================================================================
 *
 * PURPOSE:
 * This document establishes standardized exception handling patterns for Java
 * enterprise applications. It serves as a definitive guide for developers,
 * architects, and AI models to implement consistent error handling.
 *
 * KEY PRINCIPLES:
 * 1. Hierarchical Exception Structure
 *    - Clear inheritance hierarchy
 *    - Domain-specific exceptions
 *    - Separation of business and system exceptions
 *
 * 2. Meaningful Error Messages
 *    - Unique error codes
 *    - Internationalization support
 *    - User-friendly messages
 *    - Detailed technical logs
 *
 * 3. Proper Exception Propagation
 *    - Layer-appropriate handling
 *    - Exception translation
 *    - Maintaining exception chain
 *
 * 4. Centralized Error Handling
 *    - Global exception handlers
 *    - Consistent error responses
 *    - Standardized logging
 *
 * 5. Security Considerations
 *    - No sensitive data in responses
 *    - Proper error masking
 *    - Audit logging
 *
 * USAGE:
 * - Development Teams: Use as implementation guide
 * - Code Reviews: Use as review checklist
 * - AI Models: Use for code generation and validation
 * - Architecture: Use for design decisions
 *
 * BENEFITS:
 * - Consistent error handling across application
 * - Improved debugging and troubleshooting
 * - Better user experience
 * - Enhanced security
 * - Easier maintenance
 *
 * INTEGRATION:
 * - CI/CD: Include in automated checks
 * - Testing: Use in test case design
 * - Documentation: Include in API docs
 * - Monitoring: Use for error tracking
 *
 * =============================================================================
 */

## Table of Contents
1. [Exception Hierarchy](#exception-hierarchy)
2. [Error Message Standards](#error-message-standards)
3. [Exception Handling Patterns](#exception-handling-patterns)
4. [Global Exception Handling](#global-exception-handling)
5. [Error Response Structure](#error-response-structure)
6. [Logging Guidelines](#logging-guidelines)
7. [Best Practices](#best-practices)

## Exception Hierarchy

### Base Exception Classes

/*
 * =============================================================================
 * EXCEPTION HIERARCHY IMPLEMENTATION
 * =============================================================================
 *
 * This section defines the core exception classes that form the foundation
 * of our exception handling framework. The hierarchy is designed to:
 *
 * 1. Provide clear categorization of exceptions
 * 2. Enable consistent handling of similar errors
 * 3. Support detailed error information
 * 4. Enable proper error tracking and logging
 *
 * Structure:
 * BaseException (abstract)
 * ├── BusinessException
 * │   ├── ValidationException
 * │   ├── CustomerException
 * │   └── OrderException
 * └── SystemException
 *     ├── DatabaseException
 * |   └── IntegrationException
 *
 * Usage Pattern:
 * - BusinessException: For recoverable business logic errors
 * - SystemException: For unrecoverable technical errors
 * - ValidationException: For input validation errors
 * - Domain-specific exceptions: For domain-specific error cases
 */

```java
/**
 * Base exception class for all application exceptions.
 * 
 * Features:
 * - Unique error codes
 * - Internationalization support through message keys
 * - Error severity levels
 * - Support for message parameters
 * 
 * Usage:
 * @throws BaseException when any application-specific error occurs
 * 
 * Example:
 * throw new BusinessException("ORD-001", "order.not.found", orderId);
 */
public abstract class BaseException extends RuntimeException {
    private final String errorCode;
    private final String messageKey;
    private final ErrorSeverity severity;
    private final transient Object[] messageArgs;

    protected BaseException(String errorCode, 
                          String messageKey, 
                          ErrorSeverity severity, 
                          Object... messageArgs) {
        this.errorCode = errorCode;
        this.messageKey = messageKey;
        this.severity = severity;
        this.messageArgs = messageArgs;
    }

    // Getters and other utility methods
}

/**
 * Business logic related exceptions
 */
public class BusinessException extends BaseException {
    public BusinessException(String errorCode, 
                           String messageKey, 
                           Object... args) {
        super(errorCode, messageKey, ErrorSeverity.ERROR, args);
    }
}

/**
 * Technical/System related exceptions
 */
public class SystemException extends BaseException {
    public SystemException(String errorCode, 
                         String messageKey, 
                         Object... args) {
        super(errorCode, messageKey, ErrorSeverity.FATAL, args);
    }
}

/**
 * Validation related exceptions
 */
public class ValidationException extends BusinessException {
    private final List<ValidationError> validationErrors;

    public ValidationException(String errorCode, 
                             List<ValidationError> errors) {
        super(errorCode, "validation.failed");
        this.validationErrors = errors;
    }
}
```

### Domain-Specific Exceptions
```java
/**
 * Customer domain exceptions
 */
public class CustomerException extends BusinessException {
    public static final String CUSTOMER_NOT_FOUND = "CUS-001";
    public static final String CUSTOMER_ALREADY_EXISTS = "CUS-002";
    public static final String CUSTOMER_INACTIVE = "CUS-003";
    public static final String INVALID_CUSTOMER_DATA = "CUS-004";

    public CustomerException(String errorCode, Object... args) {
        super(errorCode, "customer." + errorCode, args);
    }
}

/**
 * Order domain exceptions
 */
public class OrderException extends BusinessException {
    public static final String ORDER_NOT_FOUND = "ORD-001";
    public static final String INVALID_ORDER_STATUS = "ORD-002";
    public static final String ORDER_ALREADY_PROCESSED = "ORD-003";
    public static final String INSUFFICIENT_INVENTORY = "ORD-004";

    public OrderException(String errorCode, Object... args) {
        super(errorCode, "order." + errorCode, args);
    }
}
```

## Error Message Standards

### Error Message Structure

/*
 * =============================================================================
 * ERROR MESSAGE STANDARDIZATION
 * =============================================================================
 *
 * This section defines the structure and standards for error messages.
 * A well-designed error message system should:
 *
 * 1. Error Message Components:
 *    - Error Code: Unique identifier for the error
 *    - Message: User-friendly description
 *    - Timestamp: When the error occurred
 *    - Correlation ID: For tracking across systems
 *    - Details: Additional context (optional)
 *
 * 2. Message Characteristics:
 *    - Clear and concise
 *    - Actionable for users
 *    - Sufficient for troubleshooting
 *    - Properly localized
 *    - Secure (no sensitive data)
 *
 * 3. Implementation Considerations:
 *    - Message externalization
 *    - Localization support
 *    - Performance impact
 *    - Security implications
 *
 * 4. Integration Points:
 *    - Logging systems
 *    - Monitoring tools
 *    - User interfaces
 *    - API responses
 */

```java
public class ErrorMessage {
    private final String code;
    private final String message;
    private final LocalDateTime timestamp;
    private final String correlationId;
    private final Map<String, Object> details;

    // Constructor and getters
}

public enum ErrorSeverity {
    INFO("Information only, no action required"),
    WARNING("Potential issue, action may be required"),
    ERROR("Error occurred, action required"),
    FATAL("Critical error, immediate action required");

    private final String description;

    ErrorSeverity(String description) {
        this.description = description;
    }
}
```

### Error Code Pattern
```
[Domain]-[Category]-[Sequence Number]

Examples:
CUS-VAL-001: Customer validation error
ORD-BUS-002: Order business logic error
PAY-SYS-003: Payment system error
SEC-AUT-004: Security authentication error
```

### Message Resource Bundle
```properties
# messages.properties
customer.CUS-001=Customer with ID {0} not found
customer.CUS-002=Customer with email {0} already exists
customer.CUS-003=Customer {0} is currently inactive
customer.CUS-004=Invalid customer data: {0}

order.ORD-001=Order with ID {0} not found
order.ORD-002=Invalid order status transition from {0} to {1}
order.ORD-003=Order {0} has already been processed
order.ORD-004=Insufficient inventory for product {0}
```

## Exception Handling Patterns

/*
 * =============================================================================
 * LAYER-SPECIFIC EXCEPTION HANDLING PATTERNS
 * =============================================================================
 *
 * This section outlines how exceptions should be handled at different layers
 * of the application. Each layer has specific responsibilities in the
 * exception handling chain.
 *
 * 1. Controller Layer (API Layer)
 *    - Handles HTTP-specific exceptions
 *    - Converts exceptions to appropriate HTTP responses
 *    - Ensures consistent API error format
 *    - Logs API-level errors
 *
 * 2. Service Layer (Business Layer)
 *    - Handles business logic exceptions
 *    - Translates technical exceptions to business exceptions
 *    - Implements transaction boundaries
 *    - Performs business validations
 *
 * 3. Repository Layer (Data Layer)
 *    - Handles data access exceptions
 *    - Translates DB exceptions to domain exceptions
 *    - Manages connection errors
 *    - Handles data integrity issues
 *
 * Exception Flow:
 * Client → Controller → Service → Repository
 *       ←           ←         ←
 * 
 * Best Practices:
 * 1. Each layer should only handle exceptions it can process
 * 2. Use exception translation between layers
 * 3. Maintain exception chain for debugging
 * 4. Log exceptions at appropriate levels
 */

### Service Layer Exception Handling
```java
@Service
@Transactional
public class CustomerService {
    
    private final CustomerRepository customerRepository;
    private final MessageSource messageSource;

    public Customer createCustomer(CustomerDTO dto) {
        try {
            validateCustomerData(dto);
            checkCustomerExists(dto.getEmail());
            
            Customer customer = customerMapper.toEntity(dto);
            return customerRepository.save(customer);
            
        } catch (DataIntegrityViolationException e) {
            throw new CustomerException(
                CustomerException.CUSTOMER_ALREADY_EXISTS,
                dto.getEmail()
            );
        } catch (Exception e) {
            throw new SystemException(
                "SYS-001",
                "system.unexpected.error",
                e.getMessage()
            );
        }
    }

    private void validateCustomerData(CustomerDTO dto) {
        List<ValidationError> errors = new ArrayList<>();
        
        if (StringUtils.isBlank(dto.getName())) {
            errors.add(new ValidationError(
                "name", 
                "validation.required",
                "Name is required"
            ));
        }
        
        if (!errors.isEmpty()) {
            throw new ValidationException("VAL-001", errors);
        }
    }
}
```

### Controller Layer Exception Handling
```java
@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
    
    private final CustomerService customerService;
    private final MessageSource messageSource;

    @PostMapping
    public ResponseEntity<CustomerResponse> createCustomer(
            @Valid @RequestBody CustomerRequest request,
            Locale locale) {
        try {
            Customer customer = customerService.createCustomer(
                customerMapper.toDTO(request)
            );
            return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(customerMapper.toResponse(customer));
                
        } catch (CustomerException e) {
            // Let the global exception handler handle it
            throw e;
        }
    }
}
```

## Global Exception Handling

### Global Exception Handler
```java
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private final MessageSource messageSource;
    private final ErrorResponseBuilder errorResponseBuilder;

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusinessException(
            BusinessException ex, 
            WebRequest request) {
        
        String message = messageSource.getMessage(
            ex.getMessageKey(),
            ex.getMessageArgs(),
            LocaleContextHolder.getLocale()
        );

        ErrorResponse errorResponse = errorResponseBuilder
            .withErrorCode(ex.getErrorCode())
            .withMessage(message)
            .withStatus(HttpStatus.BAD_REQUEST)
            .withCorrelationId(getCorrelationId())
            .build();

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .body(errorResponse);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(
            ValidationException ex, 
            WebRequest request) {
        
        ErrorResponse errorResponse = errorResponseBuilder
            .withErrorCode(ex.getErrorCode())
            .withMessage("Validation failed")
            .withStatus(HttpStatus.BAD_REQUEST)
            .withCorrelationId(getCorrelationId())
            .withValidationErrors(ex.getValidationErrors())
            .build();

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .body(errorResponse);
    }

    @ExceptionHandler(SystemException.class)
    public ResponseEntity<ErrorResponse> handleSystemException(
            SystemException ex, 
            WebRequest request) {
        
        // Log the detailed error for debugging
        log.error("System error occurred", ex);

        ErrorResponse errorResponse = errorResponseBuilder
            .withErrorCode(ex.getErrorCode())
            .withMessage("An internal error occurred")
            .withStatus(HttpStatus.INTERNAL_SERVER_ERROR)
            .withCorrelationId(getCorrelationId())
            .build();

        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(errorResponse);
    }
}
```

## Error Response Structure

### API Error Response
```java
@Builder
@JsonInclude(Include.NON_NULL)
public class ErrorResponse {
    private final String errorCode;
    private final String message;
    private final HttpStatus status;
    private final String correlationId;
    private final LocalDateTime timestamp;
    private final List<ValidationError> validationErrors;
    private final Map<String, Object> details;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}

public class ValidationError {
    private final String field;
    private final String code;
    private final String message;
    
    // Constructor and getters
}
```

### Example Error Responses

```json
// Business Error
{
    "errorCode": "CUS-001",
    "message": "Customer with ID 123 not found",
    "status": "NOT_FOUND",
    "correlationId": "abc-xyz-123",
    "timestamp": "2025-10-12T10:30:00Z"
}

// Validation Error
{
    "errorCode": "VAL-001",
    "message": "Validation failed",
    "status": "BAD_REQUEST",
    "correlationId": "def-uvw-456",
    "timestamp": "2025-10-12T10:35:00Z",
    "validationErrors": [
        {
            "field": "email",
            "code": "validation.email",
            "message": "Invalid email format"
        },
        {
            "field": "phone",
            "code": "validation.required",
            "message": "Phone number is required"
        }
    ]
}
```

## Logging Guidelines

### Exception Logging
```java
@Slf4j
@Component
public class ExceptionLogger {

    public void logException(BaseException ex, String correlationId) {
        MDC.put("correlationId", correlationId);
        MDC.put("errorCode", ex.getErrorCode());
        MDC.put("severity", ex.getSeverity().name());

        if (ex.getSeverity() == ErrorSeverity.FATAL) {
            log.error("Fatal error occurred: {}", ex.getMessage(), ex);
        } else if (ex.getSeverity() == ErrorSeverity.ERROR) {
            log.error("Error occurred: {}", ex.getMessage());
        } else {
            log.warn("Warning: {}", ex.getMessage());
        }

        MDC.clear();
    }
}
```

## Best Practices

/*
 * =============================================================================
 * EXCEPTION HANDLING BEST PRACTICES AND GUIDELINES
 * =============================================================================
 *
 * This section provides comprehensive guidelines for implementing robust
 * exception handling in enterprise Java applications.
 *
 * Core Principles:
 * 1. Fail Fast
 *    - Detect and report errors as early as possible
 *    - Don't continue with invalid state
 *    - Validate inputs at boundaries
 *
 * 2. Exception Granularity
 *    - Use specific exceptions for specific errors
 *    - Group related exceptions logically
 *    - Maintain clear exception hierarchy
 *
 * 3. Exception Propagation
 *    - Handle exceptions at appropriate levels
 *    - Don't catch exceptions you can't handle
 *    - Preserve stack traces
 *
 * 4. Error Messages
 *    - Clear and actionable messages
 *    - Include relevant context
 *    - Support internationalization
 *
 * 5. Security Considerations
 *    - Don't expose sensitive information
 *    - Log securely
 *    - Handle security exceptions appropriately
 *
 * 6. Performance Impact
 *    - Consider exception creation cost
 *    - Use exceptions for exceptional conditions
 *    - Cache frequently used exceptions
 *
 * Common Anti-patterns to Avoid:
 *  Catching Exception (too generic)
 *  Empty catch blocks
 *  Catching Throwable
 *  Log and throw
 *  Breaking exception chain
 *  Using exceptions for flow control
 *
 * Testing Considerations:
 * - Test happy path and error scenarios
 * - Verify error messages
 * - Check exception chains
 * - Test logging behavior
 * - Validate error responses
 */

### 1. Exception Handling Rules
- Never catch `Exception` (too generic)
- Don't ignore exceptions (empty catch blocks)
- Don't log and throw
- Use custom exceptions for business logic
- Include relevant error information
- Keep the exception hierarchy simple
- Use runtime exceptions for unrecoverable errors

### 2. Error Messages
- Use unique error codes
- Keep messages user-friendly
- Include troubleshooting information
- Support internationalization
- Avoid exposing sensitive information
- Use proper error categories

### 3. Exception Propagation
- Handle exceptions at the appropriate level
- Don't catch exceptions you can't handle
- Wrap low-level exceptions in domain exceptions
- Use exception translation when crossing boundaries
- Maintain the exception chain

### 4. Performance Considerations
- Don't use exceptions for flow control
- Cache message resources
- Use exception pooling for frequently thrown exceptions
- Consider exception handling overhead
- Proper use of try-with-resources

### Error Code Standards
```java
public final class ErrorCodes {
    // Customer Domain (CUS)
    public static final String CUSTOMER_NOT_FOUND = "CUS-001";
    public static final String CUSTOMER_ALREADY_EXISTS = "CUS-002";
    
    // Order Domain (ORD)
    public static final String ORDER_NOT_FOUND = "ORD-001";
    public static final String ORDER_INVALID_STATUS = "ORD-002";
    
    // Payment Domain (PAY)
    public static final String PAYMENT_FAILED = "PAY-001";
    public static final String PAYMENT_TIMEOUT = "PAY-002";
    
    // Validation (VAL)
    public static final String VALIDATION_FAILED = "VAL-001";
    public static final String INVALID_INPUT = "VAL-002";
    
    // System (SYS)
    public static final String SYSTEM_ERROR = "SYS-001";
    public static final String DATABASE_ERROR = "SYS-002";
    
    private ErrorCodes() {
        throw new AssertionError("Utility class - do not instantiate");
    }
}
```

## Version History
- 1.0.0 (October 12, 2025)
  - Initial version with comprehensive exception handling guidelines
  - Added detailed error message standards
  - Included exception hierarchy templates
  - Added logging guidelines
  - Implemented global exception handling patterns
