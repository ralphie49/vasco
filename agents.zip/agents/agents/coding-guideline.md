# Java Coding Guidelines
> Version: 1.0.0  
> Created: October 12, 2025  
> Last Updated: October 12, 2025

## Table of Contents
1. [Code Organization](#code-organization)
2. [Naming Conventions](#naming-conventions)
3. [Code Style](#code-style)
4. [Documentation](#documentation)
5. [Exception Handling](#exception-handling)
6. [Testing](#testing)
7. [Security](#security)
8. [Performance](#performance)
9. [Clean Code Principles](#clean-code-principles)
10. [SonarQube & PMD Rules](#sonarqube--pmd-rules)

## Code Organization

### Project Structure
```
src/
├── main/
│   ├── java/
│   │   └── com/company/project/
│   │       ├── config/        # Configuration classes
│   │       ├── controller/    # REST controllers
│   │       ├── service/       # Business logic
│   │       ├── repository/    # Data access
│   │       ├── model/        # Domain models
│   │       ├── dto/          # Data transfer objects
│   │       ├── exception/    # Custom exceptions
│   │       └── util/         # Utilities
│   └── resources/
└── test/
    └── java/
        └── com/company/project/
```

### Package Rules
- One package = One responsibility
- Avoid cyclic dependencies between packages
- Keep package depth <= 4 levels
- Use meaningful package names that reflect domain concepts

## Naming Conventions

### General Rules
- Use meaningful and pronounceable names
- Use searchable names
- Avoid abbreviations except for widely accepted ones
- Use consistent nomenclature

### Specific Naming Rules
```java
// Class names: PascalCase
public class CustomerService { }

// Interface names: PascalCase, may start with 'I'
public interface IPaymentGateway { }

// Method names: camelCase, verb or verb phrase
public void processPayment() { }

// Variables: camelCase, noun or noun phrase
private final String userFirstName;

// Constants: UPPER_CASE with underscores
public static final int MAX_RETRY_ATTEMPTS = 3;

// Packages: all lowercase, no underscores
package com.company.project.service;

// Enums: PascalCase for enum name, UPPER_CASE for values
public enum PaymentStatus {
    PENDING, COMPLETED, FAILED
}
```

## Code Style

### Class Structure
1. Static fields
2. Instance fields
3. Constructors
4. Public methods
5. Protected methods
6. Private methods
7. Inner classes/interfaces

### Class Size Guidelines
- Maximum 10 methods per class
- If more methods are needed:
  - Create utility classes for related functionality
  - Split the class based on responsibilities
  - Consider using composition over inheritance
- Utility classes should:
  - Be final
  - Have private constructor
  - Contain only static methods
  - Group related functionality

Example of a Utility Class:
```java
public final class StringUtils {
    private StringUtils() {
        throw new UnsupportedOperationException("Utility class, cannot be instantiated");
    }

    public static String normalize(String input) {
        // implementation
    }

    // Other utility methods...
}
```

### Method Guidelines
- Methods should be small (preferably <= 100 lines)
- Single Responsibility Principle: One method = One task
- Maximum 3-4 parameters per method
- Avoid boolean parameters (split into two methods)
- Return empty collections instead of null

```java
// Good
public List<Customer> getCustomers() {
    return customers != null ? customers : Collections.emptyList();
}

// Bad
public List<Customer> getCustomers() {
    return customers; // might return null
}
```

### Control Structures
```java
// Prefer early returns
public void processUser(User user) {
    if (user == null) {
        return;
    }
    // Process user
}

// Prefer Optional over null checks
Optional<User> user = userRepository.findById(id);
user.ifPresent(this::processUser);

// Prefer foreach over traditional for loops
List<String> items = Arrays.asList("A", "B", "C");
items.forEach(System.out::println);
```

## Documentation

### Class Documentation
```java
/**
 * Handles the business logic for customer operations.
 * <p>
 * This service provides methods for creating, updating, and
 * deleting customer information in the system.
 * </p>
 *
 * @author Developer Name
 * @version 1.0
 * @since 2025-10-12
 */
public class CustomerService { }
```

### Method Documentation
```java
/**
 * Creates a new customer in the system.
 *
 * @param customerDTO the customer information to be created
 * @return the created customer entity
 * @throws CustomerAlreadyExistsException if customer with same email exists
 * @throws ValidationException if customer data is invalid
 */
public Customer createCustomer(CustomerDTO customerDTO) { }
```

## Exception Handling

### Best Practices
1. Never catch Exception (too generic)
2. Don't ignore exceptions
3. Don't log and throw
4. Use custom exceptions for business logic
5. Include relevant error information

```java
// Custom Exception
public class CustomerNotFoundException extends BusinessException {
    public CustomerNotFoundException(String message) {
        super(message);
    }
}

// Proper Exception Handling
public Customer getCustomer(Long id) {
    try {
        return customerRepository.findById(id)
            .orElseThrow(() -> new CustomerNotFoundException(
                String.format("Customer not found with id: %d", id)));
    } catch (DataAccessException e) {
        log.error("Database error while fetching customer", e);
        throw new SystemException("Unable to retrieve customer data");
    }
}
```

## Testing

### Unit Testing Guidelines
1. Follow AAA (Arrange-Act-Assert) pattern
2. One test = One scenario
3. Use meaningful test names
4. Tests should be independent
5. Use appropriate assertions

```java
@Test
void shouldThrowExceptionWhenCustomerNotFound() {
    // Arrange
    Long customerId = 1L;
    when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

    // Act & Assert
    assertThrows(CustomerNotFoundException.class, 
        () -> customerService.getCustomer(customerId));
}
```

## API Design

### REST API Guidelines
- Use proper HTTP methods (GET, POST, PUT, DELETE)
- Implement proper versioning (e.g., /v1/api/)
- Use nouns for resources, not verbs
- Implement proper pagination
- Use proper HTTP status codes
- Include proper error responses

```java
@RestController
@RequestMapping("/v1/api/customers")
public class CustomerController {
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomer(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getCustomer(id));
    }

    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(
            @Valid @RequestBody CustomerDTO customer) {
        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(customerService.createCustomer(customer));
    }
}
```

### API Documentation Standards
- Use OpenAPI (Swagger) annotations
- Document all possible responses
- Include example requests/responses
- Document error scenarios
- Include rate limiting information

## Security

### Best Practices
1. Input Validation
2. Output Encoding
3. Parameterized Queries
4. Secure Password Storage
5. HTTPS Only
6. Proper Session Management

```java
// Input Validation
@ValidateRequest
public void processInput(@Valid @NotNull UserInput input) { }

// Parameterized Queries
@Query("SELECT u FROM User u WHERE u.email = :email")
Optional<User> findByEmail(@Param("email") String email);
```

## Performance

### Caching Guidelines
- Implement caching for frequently accessed data
- Use appropriate cache levels (L1/L2)
- Set proper TTL (Time To Live) values
- Implement cache eviction policies
- Use distributed caching for microservices

```java
@Service
public class CustomerService {
    @Cacheable(value = "customers", key = "#id")
    public Customer getCustomer(Long id) {
        return customerRepository.findById(id)
            .orElseThrow(() -> new CustomerNotFoundException(id));
    }

    @CacheEvict(value = "customers", key = "#id")
    public void updateCustomer(Long id, Customer customer) {
        // Update logic
    }
}
```

### General Performance Guidelines
1. Use StringBuilder for string concatenation in loops
2. Prefer primitive types over wrapper classes when possible
3. Use appropriate collection types
4. Close resources properly (try-with-resources)
5. Use lazy loading when appropriate

```java
// Resource Management
try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
    return reader.lines().collect(Collectors.toList());
}

// Collection Choice
Set<String> uniqueItems = new HashSet<>();  // O(1) lookup
List<String> orderedItems = new ArrayList<>();  // O(1) append
```

## Architecture Patterns

### Microservices Guidelines
- Service independence and loose coupling
- Database per service when possible
- Asynchronous communication using events
- API versioning required
- Circuit breaker implementation for external calls
- Service discovery integration

### Design Patterns
- Use Factory pattern for object creation complexity
- Builder pattern for objects with many parameters
- Strategy pattern for varying algorithms
- Observer pattern for event handling
- Repository pattern for data access
- Decorator pattern for extending functionality

### Multi-threading Best Practices
- Use ExecutorService over raw threads
- Implement proper thread pooling
- Avoid synchronized blocks when possible
- Use atomic classes for counters
- Implement proper resource locking
- Handle thread interruption properly

```java
// Thread Pool Example
@Configuration
public class ThreadPoolConfig {
    @Bean
    public ExecutorService executorService() {
        return Executors.newFixedThreadPool(
            Runtime.getRuntime().availableProcessors()
        );
    }
}
```

## Clean Code Principles

### SOLID Principles
1. **S**ingle Responsibility Principle
2. **O**pen/Closed Principle
3. **L**iskov Substitution Principle
4. **I**nterface Segregation Principle
5. **D**ependency Inversion Principle

### DRY (Don't Repeat Yourself)
```java
// Extract common functionality
private void validateUser(User user) {
    // Common validation logic
}
```

## SonarQube & PMD Rules

### Critical Rules
1. No hardcoded credentials
2. No unused variables/imports
3. No empty catch blocks
4. No commented-out code
5. No redundant null checks

### Major Rules
1. Proper exception handling
2. Method complexity (Cyclomatic complexity < 10)
3. Code duplication < 3%
4. Test coverage > 80%
5. No magic numbers

### Code Examples
```java
// Bad - Magic Numbers
if (status == 1) { }

// Good - Named Constants
private static final int STATUS_ACTIVE = 1;
if (status == STATUS_ACTIVE) { }

// Bad - Empty Catch
try {
    processData();
} catch (Exception e) { }

// Good - Proper Exception Handling
try {
    processData();
} catch (Exception e) {
    log.error("Error processing data", e);
    throw new SystemException("Data processing failed", e);
}
```

## Version History
- 1.0.0 (October 12, 2025)
  - Initial version with comprehensive coding guidelines
  - Included SonarQube and PMD rules
  - Added best practices for Spring Boot applications
