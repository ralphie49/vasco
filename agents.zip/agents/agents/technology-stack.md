# Technology Stack Reference Guide
> Version: 1.0  
> Created: October 12, 2025  
> Last Updated: October 12, 2025

This document outlines the recommended technology stack and library versions for Java Spring Boot projects. Each component is marked with a flag indicating whether it's required or optional for the project setup.

## Core Technologies

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| Java | 17 LTS | Yes | Long Term Support version, recommended for enterprise applications |
| Spring Boot | 3.1.5 | Yes | Latest stable version compatible with Java 17 |
| Spring Framework | 6.0.13 | Yes | Automatically managed by Spring Boot |
| Maven | 3.9.5 | Yes | Build and dependency management tool |
| Gradle | 8.4 | No | Alternative build tool to Maven |

## Database Technologies

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| MySQL | 8.0.x | Yes | Open-source relational database |
| PostgreSQL | 15.x | No | Advanced open-source relational database |
| Spring Data JPA | 3.1.5 | Yes* | *Required if using relational databases |
| Hibernate | 6.2.13.Final | Yes* | *Required if using JPA |
| Flyway | 9.22.3 | No | Database migration tool |
| Liquibase | 4.23.2 | No | Alternative database migration tool |

## Common Libraries & Utilities

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| Lombok | 1.18.30 | No | Reduces boilerplate code |
| MapStruct | 1.5.5.Final | No | Object mapping library |
| Jackson | 2.15.3 | Yes | JSON processing library |
| SLF4J | 2.0.9 | Yes | Logging facade |
| Logback | 1.4.11 | Yes | Logging implementation |

## Testing Framework

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| JUnit Jupiter | 5.10.0 | Yes | Unit testing framework |
| Mockito | 5.6.0 | Yes | Mocking framework for unit tests |
| AssertJ | 3.24.2 | No | Fluent assertions library |
| TestContainers | 1.19.1 | No | Integration testing with containers |

## Security

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| Spring Security | 6.1.5 | No | Authentication and authorization framework |
| Spring Security OAuth2 | 6.1.5 | No | OAuth2 authorization server and resource server |
| Spring Security JWT | 6.1.5 | No | JWT token support for Spring Security |
| JJWT (io.jsonwebtoken) | 0.12.3 | No | JSON Web Token library |
| Spring Security LDAP | 6.1.5 | No | LDAP authentication support |
| Spring Security Crypto | 6.1.5 | No | Cryptography support |
| Spring Security Test | 6.1.5 | No | Security testing utilities |
| Passay | 1.6.3 | No | Password policy enforcement |
| Spring Security ACL | 6.1.5 | No | Access Control List implementation |
| Spring Security Oauth2 Client | 6.1.5 | No | OAuth2 client support |

## Documentation

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| SpringDoc OpenAPI | 2.2.0 | No | API documentation (Swagger) |
| Spring REST Docs | 3.0.1 | No | Alternative API documentation |

## Monitoring & Observability

| Technology/Library | Version | Required | Description/Notes |
|-------------------|---------|----------|------------------|
| Spring Actuator | 3.1.5 | No | Application monitoring and metrics |
| Micrometer | 1.11.5 | No | Application metrics facade |
| Prometheus | 2.44.0 | No | Metrics collection |

## Notes:

1. All versions listed are compatible with Java 17 LTS.
2. Spring Boot dependencies will manage most of the core library versions automatically.
3. When using Spring Boot starters, you don't need to specify versions for many dependencies.
4. The "Required" column indicates whether the library is typically needed for a basic Spring Boot application.
5. Version numbers should be reviewed periodically for security updates and new features.

## Project Structure Reference

This is the recommended project structure for Java Spring Boot applications:

```
{{project_name}}/    # Replace {{project_name}} with your actual project name
│── pom.xml
│── src
│   ├── main
│   │   ├── java
│   │   │   └── {{base_package}}/{{project_name_lowercase}}    # Replace with your base package structure (e.g., com/company/project)
│   │   │       ├── Application.java            # Main Spring Boot entry point (@SpringBootApplication)
│   │   │       ├── config/                     # Configuration classes (CORS, Security, Swagger, etc.)
│   │   │       ├── controller/                 # REST Controllers (@RestController)
│   │   │       ├── service/                    # Business logic (@Service)
│   │   │       ├── repository/                 # Data access layer (Spring Data JPA Repositories)
│   │   │       ├── entity/                     # JPA Entities / domain models
│   │   │       ├── dto/                        # Data Transfer Objects (request/response payloads)
│   │   │       ├── exception/                  # Custom exceptions & global handler (@ControllerAdvice)
│   │   │       ├── mapper/                     # MapStruct or manual mappers (Entity ↔ DTO)
│   │   │       └── util/                       # Utility/helper classes (date utils, constants, etc.)
│   │   └── resources
│   │       └── application.properties/yml      # Application configuration files
│   └── test
│       └── java
│           └── {{base_package}}/{{project_name_lowercase}}    # Test package structure should mirror main package structure
│               ├── controller/                 # Controller tests (@WebMvcTest)
│               ├── service/                    # Unit tests for services
│               ├── repository/                 # Data layer tests (@DataJpaTest)
│               ├── entity/                     # Entity tests
│               ├── dto/                        # Unit tests for DTOs
│               ├── mapper/                     # Unit tests for mappers
│               └── util/                       # Unit tests for utilities

Dynamic Placeholders:
- {{project_name}} : Your project name in original case (e.g., MyProject)
- {{project_name_lowercase}} : Lowercase version of project name (e.g., myproject)
- {{base_package}} : Your organization's base package path (e.g., com/company/division)

Notes:
- Package names should follow company/organization conventions
- Test structure should mirror main structure
- Each layer should have its own package
- Use appropriate Spring annotations for each layer
- Application.java should be named {{project_name}}Application.java
```

## Version History

- 1.0 (October 12, 2025) - Initial version with Spring Boot 3.1.5 compatibility
